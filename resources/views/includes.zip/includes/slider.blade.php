<section class="xs-welcome-slider">
    <div class="xs-banner-slider owl-carousel">
        <div class="xs-welcome-content" style="background-image: url(assets/images/slider/slider_4.jpg);">
            <div class="container row">
                <div class="xs-welcome-wraper banner-verion-2 color-white col-md-8 content-left">
                    <p>Charity for childrens</p>
                    <h2>Hunger is stalking the globe</h2>
                    <div class="xs-btn-wraper">
                        <a href="#" class="btn btn-outline-primary">
                            join us now
                        </a>
                        <a href="#" class="btn btn-primary">
                            <span class="badge"><i class="fa fa-heart"></i></span> Donate Now
                        </a>
                    </div>
                </div>
            </div>
            <div class="xs-black-overlay"></div>
        </div>
        <div class="xs-welcome-content" style="background-image: url(assets/images/slider/slider_5.jpg);">
            <div class="container row">
                <div class="xs-welcome-wraper banner-verion-2 color-white col-md-8 content-left">
                    <p>Charity for childrens</p>
                    <h2>Hunger is stalking the globe</h2>
                    <div class="xs-btn-wraper">
                        <a href="#" class="btn btn-outline-primary">
                            join us now
                        </a>
                        <a href="#" class="btn btn-primary">
                            <span class="badge"><i class="fa fa-heart"></i></span> Donate Now
                        </a>
                    </div>
                </div>
            </div>
            <div class="xs-black-overlay"></div>
        </div>
        <div class="xs-welcome-content" style="background-image: url(assets/images/slider/slider_6.jpg);">
            <div class="container row">
                <div class="xs-welcome-wraper banner-verion-2 color-white col-md-8 content-left">
                    <p>Charity for childrens</p>
                    <h2>Hunger is stalking the globe</h2>
                    <div class="xs-btn-wraper">
                        <a href="#" class="btn btn-outline-primary">
                            join us now
                        </a>
                        <a href="#" class="btn btn-primary">
                            <span class="badge"><i class="fa fa-heart"></i></span> Donate Now
                        </a>
                    </div>
                </div>
            </div>
            <div class="xs-black-overlay"></div>
        </div>
    </div>
</section>