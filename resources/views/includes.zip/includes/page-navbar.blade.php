<header class="xs-header header-transparent">
    <div class="container">
    <nav class="xs-menus">
    <div class="nav-header">
    <div class="nav-toggle"></div>
    <a href="{{route('welcome')}}" class="nav-logo">
    <img src="assets/images/logo.png" alt="">
    </a>
    </div>
    <div class="nav-menus-wrapper row">
    <div class="xs-logo-wraper col-lg-2 xs-padding-0">
    <a class="nav-brand" href="index.html">
    <img src="assets/images/logo.png" alt="">
    </a>
    </div>
    <div class="col-lg-7">
    <ul class="nav-menu">
    <li><a href="{{route('welcome')}}">Home</a>
    </li>
    <li><a href="{{route('about')}}">About</a></li>
    <li><a href="{{route('welcome')}}">Causes</a></li>
    <li><a href="#">Events</a></li>
    <li><a href="{{route('contact')}}">Contact</a></li>
    </ul>
    </div>
    <div class="xs-navs-button d-flex-center-end col-lg-3">
    <a href="#" class="btn btn-primary">
    <span class="badge"><i class="fa fa-heart"></i></span> Donate Now
    </a>
    </div>
    </div>
    </nav>
    </div>
    </header>