<section class="xs-banner-inner-section parallax-window" style="background-image:url('{{$page_image ?? ""}}')">
    <div class="xs-black-overlay"></div>
    <div class="container">
    <div class="color-white xs-inner-banner-content">
    <h2>{{$page_header ?? ""}}</h2>
    <p>Give a helping hand for poor people</p>
    <ul class="xs-breadcumb">
    <li class="badge badge-pill badge-primary"><a href="{{route('welcome')}}" class="color-white"> Home /</a> {{$page_title ?? ""}}</li>
    </ul>
    </div>
    </div>
    </section>